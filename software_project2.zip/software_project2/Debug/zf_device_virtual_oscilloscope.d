zf_device_virtual_oscilloscope.o :	../libraries/zf_device/zf_device_virtual_oscilloscope.c
../libraries/zf_device/zf_device_virtual_oscilloscope.c :
zf_device_virtual_oscilloscope.o :	..\libraries\zf_device\zf_device_virtual_oscilloscope.h
..\libraries\zf_device\zf_device_virtual_oscilloscope.h :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
zf_device_virtual_oscilloscope.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Platform_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Platform_Types.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
zf_device_virtual_oscilloscope.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
