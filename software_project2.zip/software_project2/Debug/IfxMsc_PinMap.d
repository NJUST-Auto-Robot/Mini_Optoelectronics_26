IfxMsc_PinMap.o :	../libraries/infineon_libraries/iLLD/TC36A/Tricore/_PinMap/IfxMsc_PinMap.c
../libraries/infineon_libraries/iLLD/TC36A/Tricore/_PinMap/IfxMsc_PinMap.c :
IfxMsc_PinMap.o :	..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_PinMap\IfxMsc_PinMap.h
..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_PinMap\IfxMsc_PinMap.h :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxMsc_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxMsc_reg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxMsc_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxMsc_regdef.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxMsc_cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxMsc_cfg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxMsc_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Port\Std\IfxPort.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Port\Std\IfxPort.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxPort_cfg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_reg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_regdef.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxScu_cfg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_bf.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_bf.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_reg.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_regdef.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxMsc_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
