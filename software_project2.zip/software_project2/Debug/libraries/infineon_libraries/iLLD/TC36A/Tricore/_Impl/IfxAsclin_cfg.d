IfxAsclin_cfg.o :	../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Impl/IfxAsclin_cfg.c
../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Impl/IfxAsclin_cfg.c :
IfxAsclin_cfg.o :	..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Impl\IfxAsclin_cfg.h
..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Impl\IfxAsclin_cfg.h :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_clock.h"
"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_clock.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h"
"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxAsclin_cfg.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxAsclin_reg.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxAsclin_reg.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxAsclin_regdef.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxAsclin_regdef.h" :
IfxAsclin_cfg.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h" :
