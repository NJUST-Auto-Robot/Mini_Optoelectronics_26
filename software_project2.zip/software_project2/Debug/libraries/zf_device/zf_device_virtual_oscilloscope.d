zf_device_virtual_oscilloscope.o :	../libraries/zf_device/zf_device_virtual_oscilloscope.c
../libraries/zf_device/zf_device_virtual_oscilloscope.c :
zf_device_virtual_oscilloscope.o :	..\libraries\zf_device\zf_device_virtual_oscilloscope.h
..\libraries\zf_device\zf_device_virtual_oscilloscope.h :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h"
"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_clock.h"
"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_clock.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h"
"E:\\software_project\\software_project2\\libraries\\zf_common\zf_common_typedef.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
zf_device_virtual_oscilloscope.o :	"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Infineon\AURIX-Studio-1.10.32\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Platform_Types.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Platform_Types.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
zf_device_virtual_oscilloscope.o :	"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"E:\\software_project\\software_project2\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
