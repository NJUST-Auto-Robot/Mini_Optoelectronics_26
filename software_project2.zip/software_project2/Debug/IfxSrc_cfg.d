IfxSrc_cfg.o :	../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Impl/IfxSrc_cfg.c
../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Impl/IfxSrc_cfg.c :
IfxSrc_cfg.o :	..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Impl\IfxSrc_cfg.h
..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Impl\IfxSrc_cfg.h :
