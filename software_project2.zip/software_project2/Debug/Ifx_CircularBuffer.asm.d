Ifx_CircularBuffer.asm.o :	../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.asm.c
../libraries/infineon_libraries/iLLD/TC36A/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.asm.c :
Ifx_CircularBuffer.asm.o :	..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h
..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_CircularBuffer.asm.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_CircularBuffer.asm.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
