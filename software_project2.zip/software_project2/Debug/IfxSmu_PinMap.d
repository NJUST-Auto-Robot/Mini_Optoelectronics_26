IfxSmu_PinMap.o :	../libraries/infineon_libraries/iLLD/TC36A/Tricore/_PinMap/IfxSmu_PinMap.c
../libraries/infineon_libraries/iLLD/TC36A/Tricore/_PinMap/IfxSmu_PinMap.c :
IfxSmu_PinMap.o :	..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_PinMap\IfxSmu_PinMap.h
..\libraries\infineon_libraries\iLLD\TC36A\Tricore\_PinMap\IfxSmu_PinMap.h :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxSmu_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxSmu_reg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxSmu_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxSmu_regdef.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\Ifx_TypesReg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Port\Std\IfxPort.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Port\Std\IfxPort.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxPort_cfg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_clock.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\zf_common\zf_common_typedef.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\ifx_types.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxSmu_PinMap.o :	"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\Download\yingfeilingADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Platform_Types.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_reg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxPort_regdef.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\_Impl\IfxScu_cfg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_bf.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_bf.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_reg.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_reg.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_regdef.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Infra\\Sfr\\TC36A\\_Reg\IfxScu_regdef.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxSmu_PinMap.o :	"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\0_NJUST\\smartcar26\\Mini_Optoelectronics_26\\software_project\\libraries\\infineon_libraries\\iLLD\\TC36A\\Tricore\Cpu\Std\Ifx_Types.h" :
