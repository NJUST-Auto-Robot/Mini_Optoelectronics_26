/*
 * Util.c
 *
 *  Created on: 2026��3��13��
 *      Author: XYY
 */

#define SIN_TABLE_SIZE 512

#include "Util.h"

static const float sinTable_f32[SIN_TABLE_SIZE + 1]
    = {0.00000000f,  0.01227154f,  0.02454123f,  0.03680722f,  0.04906767f,  0.06132074f,  0.07356456f,  0.08579731f,
       0.09801714f,  0.11022221f,  0.12241068f,  0.13458071f,  0.14673047f,  0.15885814f,  0.17096189f,  0.18303989f,
       0.19509032f,  0.20711138f,  0.21910124f,  0.23105811f,  0.24298018f,  0.25486566f,  0.26671276f,  0.27851969f,
       0.29028468f,  0.30200595f,  0.31368174f,  0.32531029f,  0.33688985f,  0.34841868f,  0.35989504f,  0.37131719f,
       0.38268343f,  0.39399204f,  0.40524131f,  0.41642956f,  0.42755509f,  0.43861624f,  0.44961133f,  0.46053871f,
       0.47139674f,  0.48218377f,  0.49289819f,  0.50353838f,  0.51410274f,  0.52458968f,  0.53499762f,  0.54532499f,
       0.55557023f,  0.56573181f,  0.57580819f,  0.58579786f,  0.59569930f,  0.60551104f,  0.61523159f,  0.62485949f,
       0.63439328f,  0.64383154f,  0.65317284f,  0.66241578f,  0.67155895f,  0.68060100f,  0.68954054f,  0.69837625f,
       0.70710678f,  0.71573083f,  0.72424708f,  0.73265427f,  0.74095113f,  0.74913639f,  0.75720885f,  0.76516727f,
       0.77301045f,  0.78073723f,  0.78834643f,  0.79583690f,  0.80320753f,  0.81045720f,  0.81758481f,  0.82458930f,
       0.83146961f,  0.83822471f,  0.84485357f,  0.85135519f,  0.85772861f,  0.86397286f,  0.87008699f,  0.87607009f,
       0.88192126f,  0.88763962f,  0.89322430f,  0.89867447f,  0.90398929f,  0.90916798f,  0.91420976f,  0.91911385f,
       0.92387953f,  0.92850608f,  0.93299280f,  0.93733901f,  0.94154407f,  0.94560733f,  0.94952818f,  0.95330604f,
       0.95694034f,  0.96043052f,  0.96377607f,  0.96697647f,  0.97003125f,  0.97293995f,  0.97570213f,  0.97831737f,
       0.98078528f,  0.98310549f,  0.98527764f,  0.98730142f,  0.98917651f,  0.99090264f,  0.99247953f,  0.99390697f,
       0.99518473f,  0.99631261f,  0.99729046f,  0.99811811f,  0.99879546f,  0.99932238f,  0.99969882f,  0.99992470f,
       1.00000000f,  0.99992470f,  0.99969882f,  0.99932238f,  0.99879546f,  0.99811811f,  0.99729046f,  0.99631261f,
       0.99518473f,  0.99390697f,  0.99247953f,  0.99090264f,  0.98917651f,  0.98730142f,  0.98527764f,  0.98310549f,
       0.98078528f,  0.97831737f,  0.97570213f,  0.97293995f,  0.97003125f,  0.96697647f,  0.96377607f,  0.96043052f,
       0.95694034f,  0.95330604f,  0.94952818f,  0.94560733f,  0.94154407f,  0.93733901f,  0.93299280f,  0.92850608f,
       0.92387953f,  0.91911385f,  0.91420976f,  0.90916798f,  0.90398929f,  0.89867447f,  0.89322430f,  0.88763962f,
       0.88192126f,  0.87607009f,  0.87008699f,  0.86397286f,  0.85772861f,  0.85135519f,  0.84485357f,  0.83822471f,
       0.83146961f,  0.82458930f,  0.81758481f,  0.81045720f,  0.80320753f,  0.79583690f,  0.78834643f,  0.78073723f,
       0.77301045f,  0.76516727f,  0.75720885f,  0.74913639f,  0.74095113f,  0.73265427f,  0.72424708f,  0.71573083f,
       0.70710678f,  0.69837625f,  0.68954054f,  0.68060100f,  0.67155895f,  0.66241578f,  0.65317284f,  0.64383154f,
       0.63439328f,  0.62485949f,  0.61523159f,  0.60551104f,  0.59569930f,  0.58579786f,  0.57580819f,  0.56573181f,
       0.55557023f,  0.54532499f,  0.53499762f,  0.52458968f,  0.51410274f,  0.50353838f,  0.49289819f,  0.48218377f,
       0.47139674f,  0.46053871f,  0.44961133f,  0.43861624f,  0.42755509f,  0.41642956f,  0.40524131f,  0.39399204f,
       0.38268343f,  0.37131719f,  0.35989504f,  0.34841868f,  0.33688985f,  0.32531029f,  0.31368174f,  0.30200595f,
       0.29028468f,  0.27851969f,  0.26671276f,  0.25486566f,  0.24298018f,  0.23105811f,  0.21910124f,  0.20711138f,
       0.19509032f,  0.18303989f,  0.17096189f,  0.15885814f,  0.14673047f,  0.13458071f,  0.12241068f,  0.11022221f,
       0.09801714f,  0.08579731f,  0.07356456f,  0.06132074f,  0.04906767f,  0.03680722f,  0.02454123f,  0.01227154f,
       0.00000000f,  -0.01227154f, -0.02454123f, -0.03680722f, -0.04906767f, -0.06132074f, -0.07356456f, -0.08579731f,
       -0.09801714f, -0.11022221f, -0.12241068f, -0.13458071f, -0.14673047f, -0.15885814f, -0.17096189f, -0.18303989f,
       -0.19509032f, -0.20711138f, -0.21910124f, -0.23105811f, -0.24298018f, -0.25486566f, -0.26671276f, -0.27851969f,
       -0.29028468f, -0.30200595f, -0.31368174f, -0.32531029f, -0.33688985f, -0.34841868f, -0.35989504f, -0.37131719f,
       -0.38268343f, -0.39399204f, -0.40524131f, -0.41642956f, -0.42755509f, -0.43861624f, -0.44961133f, -0.46053871f,
       -0.47139674f, -0.48218377f, -0.49289819f, -0.50353838f, -0.51410274f, -0.52458968f, -0.53499762f, -0.54532499f,
       -0.55557023f, -0.56573181f, -0.57580819f, -0.58579786f, -0.59569930f, -0.60551104f, -0.61523159f, -0.62485949f,
       -0.63439328f, -0.64383154f, -0.65317284f, -0.66241578f, -0.67155895f, -0.68060100f, -0.68954054f, -0.69837625f,
       -0.70710678f, -0.71573083f, -0.72424708f, -0.73265427f, -0.74095113f, -0.74913639f, -0.75720885f, -0.76516727f,
       -0.77301045f, -0.78073723f, -0.78834643f, -0.79583690f, -0.80320753f, -0.81045720f, -0.81758481f, -0.82458930f,
       -0.83146961f, -0.83822471f, -0.84485357f, -0.85135519f, -0.85772861f, -0.86397286f, -0.87008699f, -0.87607009f,
       -0.88192126f, -0.88763962f, -0.89322430f, -0.89867447f, -0.90398929f, -0.90916798f, -0.91420976f, -0.91911385f,
       -0.92387953f, -0.92850608f, -0.93299280f, -0.93733901f, -0.94154407f, -0.94560733f, -0.94952818f, -0.95330604f,
       -0.95694034f, -0.96043052f, -0.96377607f, -0.96697647f, -0.97003125f, -0.97293995f, -0.97570213f, -0.97831737f,
       -0.98078528f, -0.98310549f, -0.98527764f, -0.98730142f, -0.98917651f, -0.99090264f, -0.99247953f, -0.99390697f,
       -0.99518473f, -0.99631261f, -0.99729046f, -0.99811811f, -0.99879546f, -0.99932238f, -0.99969882f, -0.99992470f,
       -1.00000000f, -0.99992470f, -0.99969882f, -0.99932238f, -0.99879546f, -0.99811811f, -0.99729046f, -0.99631261f,
       -0.99518473f, -0.99390697f, -0.99247953f, -0.99090264f, -0.98917651f, -0.98730142f, -0.98527764f, -0.98310549f,
       -0.98078528f, -0.97831737f, -0.97570213f, -0.97293995f, -0.97003125f, -0.96697647f, -0.96377607f, -0.96043052f,
       -0.95694034f, -0.95330604f, -0.94952818f, -0.94560733f, -0.94154407f, -0.93733901f, -0.93299280f, -0.92850608f,
       -0.92387953f, -0.91911385f, -0.91420976f, -0.90916798f, -0.90398929f, -0.89867447f, -0.89322430f, -0.88763962f,
       -0.88192126f, -0.87607009f, -0.87008699f, -0.86397286f, -0.85772861f, -0.85135519f, -0.84485357f, -0.83822471f,
       -0.83146961f, -0.82458930f, -0.81758481f, -0.81045720f, -0.80320753f, -0.79583690f, -0.78834643f, -0.78073723f,
       -0.77301045f, -0.76516727f, -0.75720885f, -0.74913639f, -0.74095113f, -0.73265427f, -0.72424708f, -0.71573083f,
       -0.70710678f, -0.69837625f, -0.68954054f, -0.68060100f, -0.67155895f, -0.66241578f, -0.65317284f, -0.64383154f,
       -0.63439328f, -0.62485949f, -0.61523159f, -0.60551104f, -0.59569930f, -0.58579786f, -0.57580819f, -0.56573181f,
       -0.55557023f, -0.54532499f, -0.53499762f, -0.52458968f, -0.51410274f, -0.50353838f, -0.49289819f, -0.48218377f,
       -0.47139674f, -0.46053871f, -0.44961133f, -0.43861624f, -0.42755509f, -0.41642956f, -0.40524131f, -0.39399204f,
       -0.38268343f, -0.37131719f, -0.35989504f, -0.34841868f, -0.33688985f, -0.32531029f, -0.31368174f, -0.30200595f,
       -0.29028468f, -0.27851969f, -0.26671276f, -0.25486566f, -0.24298018f, -0.23105811f, -0.21910124f, -0.20711138f,
       -0.19509032f, -0.18303989f, -0.17096189f, -0.15885814f, -0.14673047f, -0.13458071f, -0.12241068f, -0.11022221f,
       -0.09801714f, -0.08579731f, -0.07356456f, -0.06132074f, -0.04906767f, -0.03680722f, -0.02454123f, -0.01227154f,
       -0.00000000f};

static const unsigned int crc32_table[256]
    = {0x00000000, 0x04c11db7, 0x09823b6e, 0x0d4326d9, 0x130476dc, 0x17c56b6b, 0x1a864db2, 0x1e475005, 0x2608edb8,
       0x22c9f00f, 0x2f8ad6d6, 0x2b4bcb61, 0x350c9b64, 0x31cd86d3, 0x3c8ea00a, 0x384fbdbd, 0x4c11db70, 0x48d0c6c7,
       0x4593e01e, 0x4152fda9, 0x5f15adac, 0x5bd4b01b, 0x569796c2, 0x52568b75, 0x6a1936c8, 0x6ed82b7f, 0x639b0da6,
       0x675a1011, 0x791d4014, 0x7ddc5da3, 0x709f7b7a, 0x745e66cd, 0x9823b6e0, 0x9ce2ab57, 0x91a18d8e, 0x95609039,
       0x8b27c03c, 0x8fe6dd8b, 0x82a5fb52, 0x8664e6e5, 0xbe2b5b58, 0xbaea46ef, 0xb7a96036, 0xb3687d81, 0xad2f2d84,
       0xa9ee3033, 0xa4ad16ea, 0xa06c0b5d, 0xd4326d90, 0xd0f37027, 0xddb056fe, 0xd9714b49, 0xc7361b4c, 0xc3f706fb,
       0xceb42022, 0xca753d95, 0xf23a8028, 0xf6fb9d9f, 0xfbb8bb46, 0xff79a6f1, 0xe13ef6f4, 0xe5ffeb43, 0xe8bccd9a,
       0xec7dd02d, 0x34867077, 0x30476dc0, 0x3d044b19, 0x39c556ae, 0x278206ab, 0x23431b1c, 0x2e003dc5, 0x2ac12072,
       0x128e9dcf, 0x164f8078, 0x1b0ca6a1, 0x1fcdbb16, 0x018aeb13, 0x054bf6a4, 0x0808d07d, 0x0cc9cdca, 0x7897ab07,
       0x7c56b6b0, 0x71159069, 0x75d48dde, 0x6b93dddb, 0x6f52c06c, 0x6211e6b5, 0x66d0fb02, 0x5e9f46bf, 0x5a5e5b08,
       0x571d7dd1, 0x53dc6066, 0x4d9b3063, 0x495a2dd4, 0x44190b0d, 0x40d816ba, 0xaca5c697, 0xa864db20, 0xa527fdf9,
       0xa1e6e04e, 0xbfa1b04b, 0xbb60adfc, 0xb6238b25, 0xb2e29692, 0x8aad2b2f, 0x8e6c3698, 0x832f1041, 0x87ee0df6,
       0x99a95df3, 0x9d684044, 0x902b669d, 0x94ea7b2a, 0xe0b41de7, 0xe4750050, 0xe9362689, 0xedf73b3e, 0xf3b06b3b,
       0xf771768c, 0xfa325055, 0xfef34de2, 0xc6bcf05f, 0xc27dede8, 0xcf3ecb31, 0xcbffd686, 0xd5b88683, 0xd1799b34,
       0xdc3abded, 0xd8fba05a, 0x690ce0ee, 0x6dcdfd59, 0x608edb80, 0x644fc637, 0x7a089632, 0x7ec98b85, 0x738aad5c,
       0x774bb0eb, 0x4f040d56, 0x4bc510e1, 0x46863638, 0x42472b8f, 0x5c007b8a, 0x58c1663d, 0x558240e4, 0x51435d53,
       0x251d3b9e, 0x21dc2629, 0x2c9f00f0, 0x285e1d47, 0x36194d42, 0x32d850f5, 0x3f9b762c, 0x3b5a6b9b, 0x0315d626,
       0x07d4cb91, 0x0a97ed48, 0x0e56f0ff, 0x1011a0fa, 0x14d0bd4d, 0x19939b94, 0x1d528623, 0xf12f560e, 0xf5ee4bb9,
       0xf8ad6d60, 0xfc6c70d7, 0xe22b20d2, 0xe6ea3d65, 0xeba91bbc, 0xef68060b, 0xd727bbb6, 0xd3e6a601, 0xdea580d8,
       0xda649d6f, 0xc423cd6a, 0xc0e2d0dd, 0xcda1f604, 0xc960ebb3, 0xbd3e8d7e, 0xb9ff90c9, 0xb4bcb610, 0xb07daba7,
       0xae3afba2, 0xaafbe615, 0xa7b8c0cc, 0xa379dd7b, 0x9b3660c6, 0x9ff77d71, 0x92b45ba8, 0x9675461f, 0x8832161a,
       0x8cf30bad, 0x81b02d74, 0x857130c3, 0x5d8a9099, 0x594b8d2e, 0x5408abf7, 0x50c9b640, 0x4e8ee645, 0x4a4ffbf2,
       0x470cdd2b, 0x43cdc09c, 0x7b827d21, 0x7f436096, 0x7200464f, 0x76c15bf8, 0x68860bfd, 0x6c47164a, 0x61043093,
       0x65c52d24, 0x119b4be9, 0x155a565e, 0x18197087, 0x1cd86d30, 0x029f3d35, 0x065e2082, 0x0b1d065b, 0x0fdc1bec,
       0x3793a651, 0x3352bbe6, 0x3e119d3f, 0x3ad08088, 0x2497d08d, 0x2056cd3a, 0x2d15ebe3, 0x29d4f654, 0xc5a92679,
       0xc1683bce, 0xcc2b1d17, 0xc8ea00a0, 0xd6ad50a5, 0xd26c4d12, 0xdf2f6bcb, 0xdbee767c, 0xe3a1cbc1, 0xe760d676,
       0xea23f0af, 0xeee2ed18, 0xf0a5bd1d, 0xf464a0aa, 0xf9278673, 0xfde69bc4, 0x89b8fd09, 0x8d79e0be, 0x803ac667,
       0x84fbdbd0, 0x9abc8bd5, 0x9e7d9662, 0x933eb0bb, 0x97ffad0c, 0xafb010b1, 0xab710d06, 0xa6322bdf, 0xa2f33668,
       0xbcb4666d, 0xb8757bda, 0xb5365d03, 0xb1f740b4};

inline void clarke_transform(float Ia, float Ib, float Ic, float *Ialpha, float *Ibeta)
{
    *Ialpha = Ia;
    *Ibeta  = (Ib - Ic) * ONE_BY_SQRT3;
}

inline void park_transform(float Ialpha, float Ibeta, float Theta, float *Id, float *Iq)
{
    float s = sin_f32(Theta);
    float c = cos_f32(Theta);
    *Id     = Ialpha * c + Ibeta * s;
    *Iq     = -Ialpha * s + Ibeta * c;
}

inline void inverse_park(float mod_d, float mod_q, float Theta, float *mod_alpha, float *mod_beta)
{
    float s    = sin_f32(Theta);
    float c    = cos_f32(Theta);
    *mod_alpha = mod_d * c - mod_q * s;
    *mod_beta  = mod_d * s + mod_q * c;
}

/// @brief svpwm modulate
/// @param alpha Input   [-1~+1]
/// @param alpha Input   [-1~+1]
/// @param duty_a Output [0~1]
/// @param duty_b Output [0~1]
/// @param duty_c Output [0~1]
inline int svm(float alpha, float beta, float *duty_a, float *duty_b, float *duty_c)
{
    int Sextant;

    if (beta >= 0.0f) {
        if (alpha >= 0.0f) {
            //quadrant I
            if (ONE_BY_SQRT3 * beta > alpha)
                Sextant = 2; //sextant v2-v3
            else
                Sextant = 1; //sextant v1-v2

        } else {
            //quadrant II
            if (-ONE_BY_SQRT3 * beta > alpha)
                Sextant = 3; //sextant v3-v4
            else
                Sextant = 2; //sextant v2-v3
        }
    } else {
        if (alpha >= 0.0f) {
            //quadrant IV
            if (-ONE_BY_SQRT3 * beta > alpha)
                Sextant = 5; //sextant v5-v6
            else
                Sextant = 6; //sextant v6-v1
        } else {
            //quadrant III
            if (ONE_BY_SQRT3 * beta > alpha)
                Sextant = 4; //sextant v4-v5
            else
                Sextant = 5; //sextant v5-v6
        }
    }

    switch (Sextant) {
    // sextant v1-v2
    case 1: {
        // Vector on-times
        float t1 = alpha - ONE_BY_SQRT3 * beta;
        float t2 = TWO_BY_SQRT3 * beta;

        // PWM timings
        *duty_a = (1.0f - t1 - t2) * 0.5f;
        *duty_b = *duty_a + t1;
        *duty_c = *duty_b + t2;
    } break;

    // sextant v2-v3
    case 2: {
        // Vector on-times
        float t2 = alpha + ONE_BY_SQRT3 * beta;
        float t3 = -alpha + ONE_BY_SQRT3 * beta;

        // PWM timings
        *duty_b = (1.0f - t2 - t3) * 0.5f;
        *duty_a = *duty_b + t3;
        *duty_c = *duty_a + t2;
    } break;

    // sextant v3-v4
    case 3: {
        // Vector on-times
        float t3 = TWO_BY_SQRT3 * beta;
        float t4 = -alpha - ONE_BY_SQRT3 * beta;

        // PWM timings
        *duty_b = (1.0f - t3 - t4) * 0.5f;
        *duty_c = *duty_b + t3;
        *duty_a = *duty_c + t4;
    } break;

    // sextant v4-v5
    case 4: {
        // Vector on-times
        float t4 = -alpha + ONE_BY_SQRT3 * beta;
        float t5 = -TWO_BY_SQRT3 * beta;

        // PWM timings
        *duty_c = (1.0f - t4 - t5) * 0.5f;
        *duty_b = *duty_c + t5;
        *duty_a = *duty_b + t4;
    } break;

    // sextant v5-v6
    case 5: {
        // Vector on-times
        float t5 = -alpha - ONE_BY_SQRT3 * beta;
        float t6 = alpha - ONE_BY_SQRT3 * beta;

        // PWM timings
        *duty_c = (1.0f - t5 - t6) * 0.5f;
        *duty_a = *duty_c + t5;
        *duty_b = *duty_a + t6;
    } break;

    // sextant v6-v1
    case 6: {
        // Vector on-times
        float t6 = -TWO_BY_SQRT3 * beta;
        float t1 = alpha + ONE_BY_SQRT3 * beta;

        // PWM timings
        *duty_a = (1.0f - t6 - t1) * 0.5f;
        *duty_c = *duty_a + t1;
        *duty_b = *duty_c + t6;
    } break;
    }

    // if any of the results becomes NaN, result_valid will evaluate to false
    int result_valid = *duty_a >= 0.0f && *duty_a <= 1.0f && *duty_b >= 0.0f && *duty_b <= 1.0f && *duty_c >= 0.0f
                       && *duty_c <= 1.0f;

    return result_valid ? 0 : -1;
}

float sin_f32(float x)
{
    float    sinVal, frac, in; /* Temporary variables for input, output */
    uint16_t index;             /* Index variable */
    float    a, b;              /* Two nearest output values */
    int32_t  n;
    float    findex;

    /* input x is in radians */
    /* Scale the input to [0 1] range from [0 2*PI] , divide input by 2*pi */
    in = x * 0.159154943092f;

    /* Calculation of floor value of input */
    n = (int32_t) in;

    /* Make negative values towards -infinity */
    if (x < 0.0f) {
        n--;
    }

    /* Map input value to [0 1] */
    in = in - (float) n;

    /* Calculation of index of the table */
    findex = (float) SIN_TABLE_SIZE * in;
    index  = (uint16_t) findex;

    /* when "in" is exactly 1, we need to rotate the index down to 0 */
    if (index >= SIN_TABLE_SIZE) {
        index = 0;
        findex -= (float) SIN_TABLE_SIZE;
    }

    /* fractional value calculation */
    frac = findex - (float) index;

    /* Read two nearest values of input value from the sin table */
    a = sinTable_f32[index];
    b = sinTable_f32[index + 1];

    /* Linear interpolation process */
    sinVal = (1.0f - frac) * a + frac * b;

    /* Return the output value */
    return (sinVal);
}

float cos_f32(float x)
{
    float    cosVal, frac, in; /* Temporary variables for input, output */
    uint16_t index;             /* Index variable */
    float    a, b;              /* Two nearest output values */
    int32_t  n;
    float    findex;

    /* input x is in radians */
    /* Scale the input to [0 1] range from [0 2*PI] , divide input by 2*pi, add 0.25 (pi/2) to read sine table */
    in = x * 0.159154943092f + 0.25f;

    /* Calculation of floor value of input */
    n = (int32_t) in;

    /* Make negative values towards -infinity */
    if (in < 0.0f) {
        n--;
    }

    /* Map input value to [0 1] */
    in = in - (float) n;

    /* Calculation of index of the table */
    findex = (float) SIN_TABLE_SIZE * in;
    index  = (uint16_t) findex;

    /* when "in" is exactly 1, we need to rotate the index down to 0 */
    if (index >= SIN_TABLE_SIZE) {
        index = 0;
        findex -= (float) SIN_TABLE_SIZE;
    }

    /* fractional value calculation */
    frac = findex - (float) index;

    /* Read two nearest values of input value from the cos table */
    a = sinTable_f32[index];
    b = sinTable_f32[index + 1];

    /* Linear interpolation process */
    cosVal = (1.0f - frac) * a + frac * b;

    /* Return the output value */
    return (cosVal);
}

uint32_t crc32(const uint8_t *data, uint32_t size)
{
    uint32_t crc = 0;
    for (uint32_t i = 0; i < size; ++i) {
        crc = (crc << 8) ^ crc32_table[((crc >> 24) ^ data[i]) & 0xFF];
    }
    return crc;
}

int uint32_to_data(uint32_t val, uint8_t *data)
{
    data[0] = *(((uint8_t *) (&val)) + 0);
    data[1] = *(((uint8_t *) (&val)) + 1);
    data[2] = *(((uint8_t *) (&val)) + 2);
    data[3] = *(((uint8_t *) (&val)) + 3);
    return 4;
}

int int32_to_data(int32_t val, uint8_t *data)
{
    data[0] = *(((uint8_t *) (&val)) + 0);
    data[1] = *(((uint8_t *) (&val)) + 1);
    data[2] = *(((uint8_t *) (&val)) + 2);
    data[3] = *(((uint8_t *) (&val)) + 3);
    return 4;
}

int uint16_to_data(uint16_t val, uint8_t *data)
{
    data[0] = *(((uint8_t *) (&val)) + 0);
    data[1] = *(((uint8_t *) (&val)) + 1);
    return 2;
}

int int16_to_data(int16_t val, uint8_t *data)
{
    data[0] = *(((uint8_t *) (&val)) + 0);
    data[1] = *(((uint8_t *) (&val)) + 1);
    return 2;
}

int float_to_data(float val, uint8_t *data)
{
    data[0] = *(((uint8_t *) (&val)) + 0);
    data[1] = *(((uint8_t *) (&val)) + 1);
    data[2] = *(((uint8_t *) (&val)) + 2);
    data[3] = *(((uint8_t *) (&val)) + 3);
    return 4;
}

uint32_t data_to_uint32(uint8_t *data)
{
    uint32_t tmp;
    *(((uint8_t *) (&tmp)) + 0) = data[0];
    *(((uint8_t *) (&tmp)) + 1) = data[1];
    *(((uint8_t *) (&tmp)) + 2) = data[2];
    *(((uint8_t *) (&tmp)) + 3) = data[3];
    return tmp;
}

int32_t data_to_int32(uint8_t *data)
{
    int32_t tmp;
    *(((uint8_t *) (&tmp)) + 0) = data[0];
    *(((uint8_t *) (&tmp)) + 1) = data[1];
    *(((uint8_t *) (&tmp)) + 2) = data[2];
    *(((uint8_t *) (&tmp)) + 3) = data[3];
    return tmp;
}

uint16_t data_to_uint16(uint8_t *data)
{
    uint16_t tmp;
    *(((uint8_t *) (&tmp)) + 0) = data[0];
    *(((uint8_t *) (&tmp)) + 1) = data[1];
    return tmp;
}

int16_t data_to_int16(uint8_t *data)
{
    int16_t tmp;
    *(((uint8_t *) (&tmp)) + 0) = data[0];
    *(((uint8_t *) (&tmp)) + 1) = data[1];
    return tmp;
}

float data_to_float(uint8_t *data)
{
    float tmp_float;
    *(((uint8_t *) (&tmp_float)) + 0) = data[0];
    *(((uint8_t *) (&tmp_float)) + 1) = data[1];
    *(((uint8_t *) (&tmp_float)) + 2) = data[2];
    *(((uint8_t *) (&tmp_float)) + 3) = data[3];
    return tmp_float;
}

